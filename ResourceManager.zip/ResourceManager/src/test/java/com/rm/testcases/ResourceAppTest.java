package com.rm.testcases;

import static org.junit.Assert.assertEquals;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.test.JerseyTest;
import org.junit.Test;

import com.rm.exception.ResourceManagerException;
import com.rm.service.IResourceManagerService;
import com.rm.service.ResourceManagerServiceImpl;
import com.rm.util.RMAppConstant;
import com.rm.util.RmAppResponseUtil;
import com.rm.webserviceexecutor.JAXRSWebServiceExecutor;

public class ResourceAppTest extends JerseyTest{
	
	private static Logger logger = Logger.getLogger(ResourceAppTest.class);
	private static JAXRSWebServiceExecutor webServiceExecutor = JAXRSWebServiceExecutor.getInstance();
	private static RmAppResponseUtil appResponseUtil = RmAppResponseUtil.getInstance(); 
	private static final String SUBSCRIPTION_URL = "https://marketplace.appdirect.com/api/integration/v1/events/dummyOrder";
	private static final String USER_ASSIGNMENT_URL = "https://marketplace.appdirect.com/api/integration/v1/events/dummyAssign";
	private static IResourceManagerService resourceManagerService = (IResourceManagerService) new ResourceManagerServiceImpl();
	
	@Path("notifications")
	public static class RMAppResource {

	    /**
	     * Method handling HTTP POST requests and performs subscription. The returned object will be sent
	     * to the client as "application/json" media type.
	     *
	     * @return JSON that will be returned as a application/json response.
	     */

	    @GET
	    @Path("subscribe")
	    @Produces(MediaType.APPLICATION_JSON)
	    public Response subscribe(@QueryParam(RMAppConstant.EVENT_URL) String eventURL) {
	    	Response response = null;
	    	try {
	    		logger.info("Subscription request started");
	    		if(eventURL != null && !RMAppConstant.EMPTY_STRING.equals(eventURL)){
	    			String subScriptionId = eventURL.substring(eventURL.lastIndexOf("/") + 1);
	    			logger.debug("Event Subscription Id : "+subScriptionId);
	        		Response eventResponse =  webServiceExecutor.callWebService(eventURL, JAXRSWebServiceExecutor.METHOD_GET, JAXRSWebServiceExecutor.ACCEPT_HEADER_APPLICATION_JSON);
	        		logger.info("Status is : "+eventResponse.getStatus());
	        		String subscriptionDetailsJSON = eventResponse.readEntity(String.class);
	        		logger.debug("Response is : "+subscriptionDetailsJSON);
	        		logger.debug("Subscription Id : "+subScriptionId);
	        		String rmSubscriptionId = resourceManagerService.subscribe(subScriptionId, subscriptionDetailsJSON);
	    			response = appResponseUtil.generateAppResponse(rmSubscriptionId, RMAppConstant.TRUE_STRING, RMAppConstant.EMPTY_STRING, "Subscription successful");
	    		}
	    		
			} catch (ResourceManagerException e) {
				logger.error("Error occurred during subscription : "+e.getErrorMessage());
				response = appResponseUtil.generateAppResponse(RMAppConstant.FALSE_STRING, RMAppConstant.SUBSCRIPTION_ERROR, e.getErrorMessage());
			}
	    	logger.info("subscribe method ended");
			return response;
		}
	}
	
	@Path("users")
	public static class UserResource {
		
		@GET
		@Path("assign")
	    @Produces(MediaType.APPLICATION_JSON)
	    public Response assignUser(@QueryParam(RMAppConstant.EVENT_URL) String eventURL) {
	    	Response response = null;
	    	logger.info("assignUser method started");
	    	try {
	    		if(null != eventURL && !RMAppConstant.EMPTY_STRING.equals(eventURL)){
		    		String userEventId = eventURL.substring(eventURL.lastIndexOf("/")+1);
		    		logger.debug("Event Id : "+userEventId);
		    		Response eventResponse =  webServiceExecutor.callWebService(eventURL, JAXRSWebServiceExecutor.METHOD_GET, JAXRSWebServiceExecutor.ACCEPT_HEADER_APPLICATION_JSON);
	        		logger.info("Status is : "+eventResponse.getStatus());
	        		String userDetailsJson = eventResponse.readEntity(String.class);
					String userId  = resourceManagerService.assignUser(userEventId, userDetailsJson);
					response = appResponseUtil.generateAppResponse(userId, RMAppConstant.TRUE_STRING, RMAppConstant.EMPTY_STRING, "User Account created");
				}
			} catch (ResourceManagerException e) {
				logger.error("Error occurred in assignUser method "+e.getMessage());
				response = appResponseUtil.generateAppResponse(RMAppConstant.FALSE_STRING, RMAppConstant.USER_ERROR, e.getErrorMessage());
			}    	
	    	logger.info("assignUser method ended");
			return response;		
	    }
	}
		
	
	@Override
	protected Application configure() {
		// TODO Auto-generated method stub
		return new ResourceConfig(RMAppResource.class).register(UserResource.class) ;
	}

	
	@Test
	public void testSubScription(){
		Response response = target("notifications/subscribe").queryParam("eventUrl", SUBSCRIPTION_URL).request().get();
		assertEquals(200, response.getStatus());
	}
	
	@Test
	public void testUserAssignement(){
		Response response = target("users/assign").queryParam("eventUrl", USER_ASSIGNMENT_URL).request().get();
		assertEquals(200, response.getStatus());
	}
	
	

}
