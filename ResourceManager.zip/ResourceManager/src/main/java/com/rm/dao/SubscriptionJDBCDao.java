package com.rm.dao;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.rm.exception.ResourceManagerException;
import com.rm.util.ConverterUtil;
import com.rm.util.RMAppConstant;

public class SubscriptionJDBCDao implements IDao{
	
	private static final String INSERT_QUERY_SUBSCRIPTION 			=  "BEGIN INSERT INTO TSUBSCRIPTION(RECORD_ID, SUBSCRIPT_ID, SUBSCRIPT_OBJ, SUBSCRIPT_TS) VALUES(subScriptionIdSeq.nextval,?,?,current_timestamp) RETURNING RECORD_ID INTO ?; END;";
	private static final String SELECT_QUERY_SUBSCRIPTION 			=  "SELECT * FROM TSUBSCRIPTION WHERE SUBSCRIPT_ID=?";
	private static final String DELETE_QUERY_SUBSCRIPTION 			=  "DELETE FROM TSUBSCRIPTION WHERE RECORD_ID = ?";
	private static final String UPDATE_QUERY_UPDATE_SUBSCRIPTION 	=  "UPDATE TSUBSCRIPTION SET SUBSCRIPT_OBJ=? , SUBSCRIPT_TS=current_timestamp WHERE RECORD_ID=?";
	
	private ConverterUtil converterUtil = ConverterUtil.getInstance();
	private static Logger logger = Logger.getLogger(SubscriptionJDBCDao.class);
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public int persist(Object object) throws ResourceManagerException {
		
		logger.info("persist method started");
		int recordInserted = 0;
		JSONObject subscriptionJSONObj =  (JSONObject) object;
		String subScriptionId = null;
		if(subscriptionJSONObj.has(RMAppConstant.SUBSCRIPTION_ID)){
			subScriptionId = subscriptionJSONObj.getString(RMAppConstant.SUBSCRIPTION_ID);
		}
		try(Connection connection = JDBCConnectionHelper.getConnection()) {
			CallableStatement callableStatement = connection.prepareCall(INSERT_QUERY_SUBSCRIPTION);
			callableStatement.setString(1, subScriptionId);
			callableStatement.setBytes(2, converterUtil.convertObjectToByteArray(subscriptionJSONObj.toString()));
			callableStatement.registerOutParameter(3, Types.NUMERIC);
			callableStatement.execute();
			recordInserted = callableStatement.getInt(3);
			callableStatement.close();
			
		} catch (SQLException | IOException e) {
			logger.error("Error occurred in persist method "+e.getMessage());
			throw new ResourceManagerException(e.getMessage());
		}
		
		logger.info("persist method ended");
		return recordInserted;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object get(int id) throws ResourceManagerException {
		
		logger.info("get method started");
		Object subscription = null;
		try(Connection connection = JDBCConnectionHelper.getConnection()) {
			
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_QUERY_SUBSCRIPTION);
			preparedStatement.setInt(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next()){
				byte[] subScriptionDetails = resultSet.getBytes(3);
				subscription = converterUtil.convertByteArrayToObject(subScriptionDetails);
			}
			
		}catch(SQLException | IOException | ClassNotFoundException e){
			logger.error("Error occurred in get method "+e.getMessage());
			throw new ResourceManagerException(e.getMessage());
		}
		logger.info("get method ended");
		return subscription;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void delete(int id) throws ResourceManagerException {
		
		logger.info("delete method started");
		try(Connection connection = JDBCConnectionHelper.getConnection()) {
			
			PreparedStatement preparedStatement = connection.prepareStatement(DELETE_QUERY_SUBSCRIPTION);
			preparedStatement.setInt(1, id);
			preparedStatement.executeQuery();
		}catch(SQLException e){
			logger.error("Error occurred in delete method "+e.getMessage());
			throw new ResourceManagerException(e.getMessage());
		}
		logger.info("delete method ended");
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void update(Object object) throws ResourceManagerException {
		
		logger.info("update method started");
		JSONObject subscriptionJSONObj =  (JSONObject) object;
		int rmSubscriptionId = 0;
		if(subscriptionJSONObj.has(RMAppConstant.RM_SUBSCRIPTION_ID)){
			rmSubscriptionId = subscriptionJSONObj.getInt(RMAppConstant.RM_SUBSCRIPTION_ID);
		}
		try(Connection connection = JDBCConnectionHelper.getConnection()) {
			PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_QUERY_UPDATE_SUBSCRIPTION)	;
			preparedStatement.setObject(1, converterUtil.convertObjectToByteArray(subscriptionJSONObj.toString()));
			preparedStatement.setInt(2, rmSubscriptionId);
			preparedStatement.executeUpdate();
		}catch(SQLException | IOException e){
			logger.error("Error in update method "+e.getMessage());
			throw new ResourceManagerException(e.getMessage());
		}
		logger.info("update method ended");
	}

}
