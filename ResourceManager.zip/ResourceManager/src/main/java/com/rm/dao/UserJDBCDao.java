package com.rm.dao;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.rm.exception.ResourceManagerException;
import com.rm.util.ConverterUtil;
import com.rm.util.RMAppConstant;

public class UserJDBCDao implements IDao{
	
	private static final String INSERT_QUERY_USER = "BEGIN INSERT INTO TUSER(USER_ID, USER_EVENT_ID, USER_OBJ, USER_TS) VALUES(userIdSeq.nextval,?,?,current_timestamp) RETURNING USER_ID INTO ?; END;";
	private static final String DELETE_QUERY_USER = "DELETE FROM TUSER WHERE USER_ID = ?";
		
	private ConverterUtil converterUtil = ConverterUtil.getInstance();
	private static Logger logger = Logger.getLogger(SubscriptionJDBCDao.class);
	
	@Override
	public int persist(Object object) throws ResourceManagerException {
		
		int rmAppUserId = 0; 
		logger.info("persist method started");
		JSONObject userDetailsJsonObj = (JSONObject) object;
		String userEventId = userDetailsJsonObj.getString(RMAppConstant.USER_EVENT_ID);
		try(Connection connection = JDBCConnectionHelper.getConnection()) {
			CallableStatement callableStatement = connection.prepareCall(INSERT_QUERY_USER);
			callableStatement.setString(1, userEventId);
			callableStatement.setBytes(2, converterUtil.convertObjectToByteArray(userDetailsJsonObj.toString()));
			callableStatement.registerOutParameter(3, Types.NUMERIC);
			callableStatement.execute();
			rmAppUserId = callableStatement.getInt(3);
			callableStatement.close();
			
		} catch (SQLException | IOException e) {
			logger.info("Error occurred in persist method "+e.getMessage());
			throw new ResourceManagerException(e.getMessage());
		}
		
		logger.info("persist method ended");
		return rmAppUserId;
	}

	@Override
	public Object get(int id) throws ResourceManagerException {
		
		return null;
	}

	@Override
	public void delete(int id) throws ResourceManagerException {
		
		logger.info("delete method started");
		try(Connection connection = JDBCConnectionHelper.getConnection()) {
			PreparedStatement preparedStatement = connection.prepareStatement(DELETE_QUERY_USER);
			preparedStatement.setInt(1, id);
			preparedStatement.executeQuery();
		}catch(SQLException e){
			logger.error("Error occurred in delete method "+e.getMessage());
			throw new ResourceManagerException(e.getMessage());
		}
		logger.info("delete method ended");
	}

	@Override
	public void update(Object object) throws ResourceManagerException {
		
		
	}

}
