package com.rm.dao;

import com.rm.exception.ResourceManagerException;
/**
 * This interface handles CRUD operations
 * @author Sagar
 *
 */
public interface IDao {

	/**
	 * This method is used for persisting data into database
	 * @param object
	 * @throws ResourceManagerException
	 */
	int persist(Object object) throws ResourceManagerException;
	
	/**
	 * This method is used for getting data from database
	 * @param id
	 * @return object
	 * @throws ResourceManagerException
	 */
	Object get(int id) throws ResourceManagerException;
	
	/**
	 * This method is used for deleting data from database 
	 * @param id
	 * @throws ResourceManagerException
	 */
	void delete(int id)throws ResourceManagerException; 

	/**
	 * This method is used for updating object into database
	 * @param object
	 * @throws ResourceManagerException
	 */
	void update(Object object) throws ResourceManagerException;
	
}
