package com.rm.dao;

import com.rm.exception.ResourceManagerException;
/**
 * This class can be used for CRUD operation in ORM way. Skeleton is drawn. Implementation can be done as per developer need.
 * @author Sagar
 *
 */
public class SubscriptionORMDao implements IDao{

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int persist(Object object) throws ResourceManagerException {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object get(int id) throws ResourceManagerException {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void delete(int id) throws ResourceManagerException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void update(Object object) throws ResourceManagerException {
		// TODO Auto-generated method stub
		
	}

}
