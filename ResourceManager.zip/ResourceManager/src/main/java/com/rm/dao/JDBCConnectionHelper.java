package com.rm.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

/**
 * This class is used for handling JDBC Connection
 * @author Sagar
 *
 */
public class JDBCConnectionHelper {

	private static JDBCConnectionHelper jdbcConnectionHelper = new JDBCConnectionHelper();
	public static final String URL = "jdbc:oracle:thin:@localhost:1521:xe";
    public static final String USER = "system";
    public static final String PASSWORD = " Password";
    public static final String DRIVER_CLASS = "oracle.jdbc.driver.OracleDriver"; 
    
    private static final Logger logger = Logger.getLogger(JDBCConnectionHelper.class);
    private JDBCConnectionHelper(){
    	try {
			Class.forName(DRIVER_CLASS);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public static Connection getConnection(){
    	return jdbcConnectionHelper.createConnection();
    }

	private Connection createConnection() {
		// TODO Auto-generated method stub
		Connection connection  = null;
		try {
			connection = DriverManager.getConnection(URL, USER, PASSWORD);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("Error occurred while creating jdbc connection "+e.getMessage());
		}
		return connection;
	}
	
}
