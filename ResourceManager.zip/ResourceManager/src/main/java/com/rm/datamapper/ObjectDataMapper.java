package com.rm.datamapper;

import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rm.exception.ResourceManagerException;

public class ObjectDataMapper implements IDataMapper{

	/**
	 * {@inheritDoc}
	 */
	@Override
	public <T> T getDataFromJSON(String jsonData, Class<T> class1) throws ResourceManagerException {
		// TODO Auto-generated method stub
		T t = null;
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			t = objectMapper.readValue(jsonData, class1);
		} catch (IOException e) {
			throw new ResourceManagerException(e.getMessage());
		}
		
		return t;
	}

}
