package com.rm.datamapper;

import com.rm.exception.ResourceManagerException;
/**
 * This interface is used for converting json data to required format. This can be used when JSON to entity mapping is needed, which can be further useful in ORM framework.
 * @author Sagar
 *
 */
public interface IDataMapper {
	
	/**
	 * This method is used for converting json data to object
	 * @param jsonData
	 * @param class1
	 * @return
	 * @throws ResourceManagerException
	 */
	<T> T getDataFromJSON(String jsonData, Class<T> class1) throws ResourceManagerException;
	
	
}
