package com.rm.util;

import javax.ws.rs.core.Response;

import com.rm.vo.AppResponse;

public class RmAppResponseUtil {

	private static RmAppResponseUtil appResponseUtil;
	
	private RmAppResponseUtil() {
		// TODO Auto-generated constructor stub
	}
	
	public static RmAppResponseUtil getInstance(){
		if(appResponseUtil == null){
			appResponseUtil = new RmAppResponseUtil();
		}
		return appResponseUtil;
	}
	
	
	/**
     * This method is used for generating error response
     * @param success
     * @param errorCode
     * @param message
     * @return Response
     */
    public Response generateAppResponse(String success, String errorCode, String message) {
		// TODO Auto-generated method stub
    	AppResponse appResponse = new AppResponse(success, errorCode, message);
    	Response response = Response.ok().entity(appResponse).build();
		return response;
	}
    
    /**
     * This method is used to generate app response
     * @param accountIdentifier
     * @param success
     * @param errorCode
     * @param message
     * @return
     */
    public Response generateAppResponse(String accountIdentifier, String success, String errorCode, String message) {
		// TODO Auto-generated method stub
    	AppResponse appResponse = new AppResponse(accountIdentifier, success, errorCode, message);
    	Response response = Response.ok().entity(appResponse).build();
		return response;
	}
    
    /**
     *  This method is used to generate app response
     * @param accountIdentifier
     * @param success
     * @return
     */
    public Response generateAppResponse(String accountIdentifier, String success) {
		// TODO Auto-generated method stub
    	AppResponse appResponse = new AppResponse(accountIdentifier, success);
    	Response response = Response.ok().entity(appResponse).build();
		return response;
	}
    
    /**
     *  This method is used to generated app response
     * @param success
     * @return
     */
    public Response generateAppResponse(String success) {
		// TODO Auto-generated method stub
    	AppResponse appResponse = new AppResponse(success);
    	Response response = Response.ok().entity(appResponse).build();
		return response;
	}
}
