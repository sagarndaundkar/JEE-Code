package com.rm.util;

public class RMAppConstant {

	public static final String ACCOUNT_NOT_FOUND 	= "ACCOUNT_NOT_FOUND";
	public static final String SUBSCRIPTION_ERROR 	= "SUBSCRIPTION_ERROR";
	public static final String EMPTY_STRING 	 	= "";
	public static final String SUBSCRIPTION_SUCCESS = "SUBSCRIPTION_SUCCESS";
	public static final String SUBSCRIPTION_UPDATE  = "SUBSCRIPTION_UPDATE" ;
	public static final String SUBSCRIPTION_CANCEL 	= "SUBSCRIPTION_CANCEL";
	public static final String TRUE_STRING 			= "true";
	public static final String FALSE_STRING 		= "false";
	public static final String EVENT_URL 			= "eventUrl";
	public static final String ACCOUNT_IDENTIFIER 	= "accountIdentifier";
	public static final String PAYLOAD 				= "payload";
	public static final String ACCOUNT 				= "account";
	public static final String USER_ERROR 			= "USER_ERROR";
	public static final String SUBSCRIPTION_ID 		= "subScriptionId";
	public static final String RM_SUBSCRIPTION_ID 	= "rmSubscriptionId";
	public static final String USER_EVENT_ID 		= "userEventId";
	
}
