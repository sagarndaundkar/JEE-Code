package com.rm.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ConverterUtil {
	
	private static ConverterUtil converterUtil;
	
	private ConverterUtil() {
		// TODO Auto-generated constructor stub
	}
	
	public static ConverterUtil getInstance(){
		if(converterUtil == null){
			converterUtil =new ConverterUtil();
		}
		return converterUtil;
	}

	public byte[] convertObjectToByteArray(Object obj) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
        objectOutputStream.writeObject(obj);
        return byteArrayOutputStream.toByteArray();
	}
	
	public Object convertByteArrayToObject(byte[] objectBytes) throws IOException, ClassNotFoundException{
		ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(objectBytes);
    	ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);
    	Object object = objectInputStream.readObject();
    	return object;
	}
}
