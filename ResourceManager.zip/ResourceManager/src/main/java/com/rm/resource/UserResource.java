package com.rm.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;

import com.rm.exception.ResourceManagerException;
import com.rm.service.IResourceManagerService;
import com.rm.service.ResourceManagerServiceImpl;
import com.rm.util.RMAppConstant;
import com.rm.util.RmAppResponseUtil;
import com.rm.vo.AppResponse;
import com.rm.webserviceexecutor.JAXRSWebServiceExecutor;

/**
 * This class is used for user assignment and unassignment. 
 * @author Sagar
 *
 */
@Path("users")
public class UserResource {
	
	private IResourceManagerService resourceManagerService = (IResourceManagerService) new ResourceManagerServiceImpl();
	private static final Logger logger = Logger.getLogger(UserResource.class);
	private JAXRSWebServiceExecutor webServiceExecutor = JAXRSWebServiceExecutor.getInstance();
	private RmAppResponseUtil appResponseUtil = RmAppResponseUtil.getInstance(); 
	
	/**
	 * This method is used for user assignment.
	 * @param eventURL
	 * @return Response
	 */
	@GET
	@Path("assign")
    @Produces(MediaType.APPLICATION_JSON)
    public Response assignUser(@QueryParam(RMAppConstant.EVENT_URL) String eventURL) {
    	Response response = null;
    	logger.info("assignUser method started");
    	try {
    		if(null != eventURL && !RMAppConstant.EMPTY_STRING.equals(eventURL)){
	    		String userEventId = eventURL.substring(eventURL.lastIndexOf("/")+1);
	    		logger.debug("Event Id : "+userEventId);
	    		Response eventResponse =  webServiceExecutor.callWebService(eventURL, JAXRSWebServiceExecutor.METHOD_GET, JAXRSWebServiceExecutor.ACCEPT_HEADER_APPLICATION_JSON);
        		logger.info("Status is : "+eventResponse.getStatus());
        		String userDetailsJson = eventResponse.readEntity(String.class);
				String userId  = resourceManagerService.assignUser(userEventId, userDetailsJson);
				response = appResponseUtil.generateAppResponse(userId, RMAppConstant.TRUE_STRING);
			}
		} catch (ResourceManagerException e) {
			logger.error("Error occurred in assignUser method "+e.getMessage());
			response = appResponseUtil.generateAppResponse(RMAppConstant.FALSE_STRING, RMAppConstant.USER_ERROR, e.getErrorMessage());
		}    	
    	logger.info("assignUser method ended");
		return response;		
    }
	
	/**
	 * This method is used for unassigning user.
	 * @param eventURL
	 * @return Response
	 */
	@GET
	@Path("unassign")
    @Produces(MediaType.APPLICATION_JSON)
    public Response unassignUser(@QueryParam("eventUrl") String eventURL){
    	Response response = null;
    	logger.info("unassignUser method started");
    	try {
    		if(null != eventURL && !RMAppConstant.EMPTY_STRING.equals(eventURL)){
	    		String userEventId = eventURL.substring(eventURL.lastIndexOf("/")+1);
	    		logger.debug("Event Id : "+userEventId);
	    		Response eventResponse =  webServiceExecutor.callWebService(eventURL, JAXRSWebServiceExecutor.METHOD_GET, JAXRSWebServiceExecutor.ACCEPT_HEADER_APPLICATION_JSON);
        		logger.info("Status is : "+eventResponse.getStatus());
        		String userDetailsJson = eventResponse.readEntity(String.class);
				resourceManagerService.unassignUser(userDetailsJson);
				response = appResponseUtil.generateAppResponse(RMAppConstant.TRUE_STRING);
    		}
		} catch (ResourceManagerException e) {
			logger.error("Error occurred in unassignUser method"+e.getMessage());
			AppResponse failureSubscription = new AppResponse(RMAppConstant.FALSE_STRING, RMAppConstant.USER_ERROR, e.getErrorMessage());
			response = Response.serverError().entity(failureSubscription).build();
		}
    	logger.info("unassignUser method ended");
		return response;
	}
	
}
