package com.rm.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;

import com.rm.exception.ResourceManagerException;
import com.rm.service.IResourceManagerService;
import com.rm.service.ResourceManagerServiceImpl;
import com.rm.util.RMAppConstant;
import com.rm.util.RmAppResponseUtil;
import com.rm.webserviceexecutor.JAXRSWebServiceExecutor;

/**
 * Root resource (exposed at "notifications" path)
 */
/**
 * This class is used for managing subscription - subscribe, cancel and update subscription.
 * @author Sagar
 *
 */
@Path("notifications")
public class RMAppResource {

	private IResourceManagerService resourceManagerService = (IResourceManagerService) new ResourceManagerServiceImpl();
    private static final Logger logger = Logger.getLogger(RMAppResource.class);
    private JAXRSWebServiceExecutor webServiceExecutor = JAXRSWebServiceExecutor.getInstance();
    private RmAppResponseUtil appResponseUtil = RmAppResponseUtil.getInstance(); 
   

    /**
     * This method is used for subscription. This method internally makes GET request to eventURL provided by AppDirect and process data/response returned by this method. 
     * This method returns accountIdentifier to AppDirect in response. 
     * @param eventURL
     * @return Response
     */
    @GET
    @Path("subscribe")
    @Produces(MediaType.APPLICATION_JSON)
    public Response subscribe(@QueryParam(RMAppConstant.EVENT_URL) String eventURL) {
    	Response response = null;
    	try {
    		logger.info("Subscription request started");
    		if(eventURL != null && !RMAppConstant.EMPTY_STRING.equals(eventURL)){
    			String subScriptionId = eventURL.substring(eventURL.lastIndexOf("/") + 1);
    			logger.debug("Event Subscription Id : "+subScriptionId);
        		Response eventResponse =  webServiceExecutor.callWebService(eventURL, JAXRSWebServiceExecutor.METHOD_GET, JAXRSWebServiceExecutor.ACCEPT_HEADER_APPLICATION_JSON);
        		logger.info("Status is : "+eventResponse.getStatus());
        		String subscriptionDetailsJSON = eventResponse.readEntity(String.class);
        		logger.debug("Response is : "+subscriptionDetailsJSON);
        		logger.debug("Subscription Id : "+subScriptionId);
        		String rmSubscriptionId = resourceManagerService.subscribe(subScriptionId, subscriptionDetailsJSON);
    			response = appResponseUtil.generateAppResponse(rmSubscriptionId, RMAppConstant.TRUE_STRING);
    		}
    		
		} catch (ResourceManagerException e) {
			logger.error("Error occurred during subscription : "+e.getErrorMessage());
			response = appResponseUtil.generateAppResponse(RMAppConstant.FALSE_STRING, RMAppConstant.SUBSCRIPTION_ERROR, e.getErrorMessage());
		}
    	logger.info("subscribe method ended");
		return response;
	}
    

    
    /**
     * 
     * This method is used for canceling subscription. 
     *  
     * @return Response
     */
    @GET
    @Path("unsubscribe")
    @Produces(MediaType.APPLICATION_JSON)
    public Response unsubscribe(@QueryParam(RMAppConstant.EVENT_URL) String eventURL) { 
    	Response response = null;
    	//String rmSubscriptionId = null;
    	logger.info("unsubscribe method started");
    	try {
    		if(eventURL != null && !RMAppConstant.EMPTY_STRING.equals(eventURL)){
    			String eventId = eventURL.substring(eventURL.lastIndexOf("/") + 1);
        		logger.debug("Event Id : "+eventId);
        		Response eventResponse =  webServiceExecutor.callWebService(eventURL, JAXRSWebServiceExecutor.METHOD_GET, JAXRSWebServiceExecutor.ACCEPT_HEADER_APPLICATION_JSON);
        		System.out.println("Status is : "+eventResponse.getStatus());
        		String subscriptionDetailsJSON = eventResponse.readEntity(String.class);
        		System.out.println("Response is : "+subscriptionDetailsJSON);
        		resourceManagerService.unsubscribe(subscriptionDetailsJSON);
    			response = appResponseUtil.generateAppResponse(RMAppConstant.TRUE_STRING);
    		}
    		
		} catch (ResourceManagerException e) {
			logger.error("Error occurred during unsubscription : "+e.getErrorMessage());
			response = appResponseUtil.generateAppResponse(RMAppConstant.FALSE_STRING, RMAppConstant.SUBSCRIPTION_ERROR, e.getErrorMessage());
		}
    	logger.info("unsubscribe method ended");
        return response;
    }

	
    /**
     * This method is used for updating subscription changes.
     * @param eventURL
     * @return
     */
    @GET
    @Path("updateSubscription")
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateSubscription(@QueryParam(RMAppConstant.EVENT_URL) String eventURL){
    	Response response = null;
    	//String rmSubscriptionId = null;
    	logger.info("updateSubscription method started");
    	try {
    		if(null != eventURL && !RMAppConstant.EMPTY_STRING.equals(eventURL)){
    			String eventId = eventURL.substring(eventURL.lastIndexOf("/") + 1);
        		logger.debug("Event Id : "+eventId);
        		Response eventResponse =  webServiceExecutor.callWebService(eventURL, JAXRSWebServiceExecutor.METHOD_GET, JAXRSWebServiceExecutor.ACCEPT_HEADER_APPLICATION_JSON);
        		System.out.println("Status is : "+eventResponse.getStatus());
        		String subscriptionDetailsJSON = eventResponse.readEntity(String.class);
        		System.out.println("Response is : "+subscriptionDetailsJSON);
        		resourceManagerService.updateSubscription(subscriptionDetailsJSON);
    			response = appResponseUtil.generateAppResponse(RMAppConstant.TRUE_STRING);
    		}    		
		} catch (ResourceManagerException e) {
			logger.error("Error occurred updating subscription : "+e.getErrorMessage());
			response = appResponseUtil.generateAppResponse(RMAppConstant.FALSE_STRING, RMAppConstant.SUBSCRIPTION_ERROR, e.getErrorMessage());
		}
    	logger.info("updateSubscription method ended");
    	return response;
    }   
    
    
}
