package com.rm.service;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.rm.dataprocessor.AbstractDataProcessor;
import com.rm.exception.ResourceManagerException;
import com.rm.util.RMAppConstant;


public class ResourceManagerServiceImpl implements IResourceManagerService {

	AbstractDataProcessor dataProcessor = AbstractDataProcessor.getInstance();
	
	private static final Logger logger = Logger.getLogger(ResourceManagerServiceImpl.class);
	/**
	 * {@inheritDoc}
	 */
	@Override
	public String subscribe(String subScriptionId, String subscriptionDetailsJSON) throws ResourceManagerException {
		// TODO Auto-generated method stub
		logger.info("subscribe method started");
		JSONObject subscriptionDetailsJSONObj = new JSONObject(subscriptionDetailsJSON);
		subscriptionDetailsJSONObj.put(RMAppConstant.SUBSCRIPTION_ID, subScriptionId);
		int recordInserted = dataProcessor.getSubscriptionDao().persist(subscriptionDetailsJSONObj);	
		logger.info("subscribe method ended");
		return String.valueOf(recordInserted);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void unsubscribe(String subscriptionDetailsJSON) throws ResourceManagerException {
		// TODO Auto-generated method stub
		logger.info("unsubscribe method started");
		String rmSubscriptionIdStr = getAccountIdentifier(subscriptionDetailsJSON);
		int rmSubscriptionId = Integer.valueOf(rmSubscriptionIdStr);
		dataProcessor.getSubscriptionDao().delete(rmSubscriptionId);
		logger.info("unsubscribe method ended");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void updateSubscription(String subscriptionDetailsJSON) throws ResourceManagerException {
		// TODO Auto-generated method stub
		logger.info("updateSubscription method started");
		String rmSubscriptionIdStr = getAccountIdentifier(subscriptionDetailsJSON);
		int rmSubscriptionId = Integer.valueOf(rmSubscriptionIdStr);
		JSONObject subscriptionDetailsJSONObj = new JSONObject(subscriptionDetailsJSON);
		subscriptionDetailsJSONObj.put(RMAppConstant.RM_SUBSCRIPTION_ID, rmSubscriptionId);
		dataProcessor.getSubscriptionDao().update(subscriptionDetailsJSONObj);
		logger.info("updateSubscription method ended");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String assignUser(String userEventId, String userDetailsJson) throws ResourceManagerException {
		// TODO Auto-generated method stub
		logger.info("assignUser method started");
		JSONObject userDetailsJsonObj = new JSONObject(userDetailsJson);
		userDetailsJsonObj.put(RMAppConstant.USER_EVENT_ID, userEventId);
		int rmAppUserId = dataProcessor.getUserDao().persist(userDetailsJsonObj);	
		logger.info("assignUser method ended");
		return String.valueOf(rmAppUserId);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void unassignUser(String userDetailsJson) throws ResourceManagerException {
		// TODO Auto-generated method stub
		logger.info("unassignUser method started");
		String accountIdentifierStr = getAccountIdentifier(userDetailsJson);
		int accountIdentifier = Integer.valueOf(accountIdentifierStr);
		dataProcessor.getUserDao().delete(accountIdentifier);
		logger.info("unassignUser method ended");
	}
	
	 /**
	 * This method is used to get accountIdentifier/rmSubscriptionId from JsonString
	 * @param subScriptionDetails
	 * @return String
	 */
	private String getAccountIdentifier(String subScriptionDetails) {
		String rmSubscriptionId = null;
		if(null != subScriptionDetails && !RMAppConstant.EMPTY_STRING.equals(subScriptionDetails)){
			JSONObject jsonObject = new JSONObject(subScriptionDetails);
			if(null != jsonObject && jsonObject.has(RMAppConstant.PAYLOAD)){
				JSONObject payloadJsonObject = (JSONObject) jsonObject.get(RMAppConstant.PAYLOAD);
				if(null != payloadJsonObject && payloadJsonObject.has(RMAppConstant.ACCOUNT)){
					JSONObject accountJsonObject =  (JSONObject) payloadJsonObject.get(RMAppConstant.ACCOUNT);
					if(null != accountJsonObject){
						rmSubscriptionId = accountJsonObject.getString(RMAppConstant.ACCOUNT_IDENTIFIER);
					}
				}
			}
			System.out.println("SubScriptionId : "+rmSubscriptionId);
		}
		return rmSubscriptionId;
	}

}
