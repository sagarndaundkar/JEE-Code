package com.rm.service;

import com.rm.exception.ResourceManagerException;

/**
 * This interface manages subscription and user management.
 * @author Sagar
 *
 */
public interface IResourceManagerService {
	
	
	/**
	 * This method is used subscribing user.
	 * @param subScriptionId
	 * @param subscriptionDetailsJSON
	 * @return String accountIdentifier
	 * @throws ResourceManagerException
	 */
	String subscribe(String subScriptionId, String subscriptionDetailsJSON) throws ResourceManagerException;
	
	
	
	/**
	 * This method is used for unsubscribing.
	 * @param subscriptionDetailsJSON
	 * @throws ResourceManagerException
	 */
	void unsubscribe(String subscriptionDetailsJSON) throws ResourceManagerException;

	
	/**
	 * This method is used updating subscription details
	 * @param subscriptionDetailsJSON
	 * @throws ResourceManagerException
	 */
	void updateSubscription(String subscriptionDetailsJSON) throws ResourceManagerException;
	
	
	/**
	 * This method is used for user assignment.
	 * @param userEventId
	 * @param userDetailsJson
	 * @return String accountIdentifier
	 * @throws ResourceManagerException
	 */
	String assignUser(String userEventId, String userDetailsJson) throws ResourceManagerException;
	
	
	/**
	 * This method is used for unassigning user.
	 * @param userDetailsJson
	 * @throws ResourceManagerException
	 */
	void unassignUser(String userDetailsJson) throws ResourceManagerException;
	
}
