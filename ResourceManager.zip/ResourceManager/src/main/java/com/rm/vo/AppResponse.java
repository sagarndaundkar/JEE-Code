package com.rm.vo;

public class AppResponse
{
	private String accountIdentifier;
	
    private String message;

    private String errorCode;

    private String success;
    
    
    public AppResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AppResponse(String accountIdentifier, String success, String errorCode, String message) {
		super();
		this.accountIdentifier = accountIdentifier;
		this.message = message;
		this.errorCode = errorCode;
		this.success = success;
	}
	
	public AppResponse(String success, String errorCode, String message) {
		super();
		this.message = message;
		this.errorCode = errorCode;
		this.success = success;
	}
	
	
	public AppResponse(String accountIdentifier, String success) {
		// TODO Auto-generated constructor stub
		this.accountIdentifier = accountIdentifier;
		this.success = success;
	}

	public AppResponse(String success) {
		// TODO Auto-generated constructor stub
		this.success = success;
	}

	public String getAccountIdentifier() {
		return accountIdentifier;
	}

	public void setAccountIdentifier(String accountIdentifier) {
		this.accountIdentifier = accountIdentifier;
	}

	public String getMessage ()
    {
        return message;
    }

    public void setMessage (String message)
    {
        this.message = message;
    }

    public String getErrorCode ()
    {
        return errorCode;
    }

    public void setErrorCode (String errorCode)
    {
        this.errorCode = errorCode;
    }

    public String getSuccess ()
    {
        return success;
    }

    public void setSuccess (String success)
    {
        this.success = success;
    }

	@Override
	public String toString() {
		return "AppResponse [accountIdentifier=" + accountIdentifier
				+ ", message=" + message + ", errorCode=" + errorCode
				+ ", success=" + success + "]";
	}	
	  
}