package com.rm.dataprocessor;

import org.apache.log4j.Logger;

/**
 * This class is used for getting data processor instance
 * @author Sagar
 *
 */
public class DataProcessorHelper {

	private static final Logger logger = Logger.getLogger(DataProcessorHelper.class);
	/**
	 * This method is used for getting provided dataprocessor interface else returns default implementation
	 * @param defaultImpl
	 * @param actualImpl
	 * @return
	 */
	public static AbstractDataProcessor getInstance(String defaultImpl, String actualImpl){
		AbstractDataProcessor dataProcessor = null;
		String factoryImpl = null;
		if(actualImpl == null || "".equals(actualImpl)){
			factoryImpl = defaultImpl;
		}else{
			factoryImpl = actualImpl;
		}
		try {
			dataProcessor = (AbstractDataProcessor) Thread.currentThread().getContextClassLoader().loadClass(factoryImpl).newInstance();
		} catch (InstantiationException | IllegalAccessException
				| ClassNotFoundException e) {
			// TODO Auto-generated catch block
			logger.error("Error occurred while creating instance of dataprocessor : "+e.getMessage());
		}
		return dataProcessor;
	}
	
}
