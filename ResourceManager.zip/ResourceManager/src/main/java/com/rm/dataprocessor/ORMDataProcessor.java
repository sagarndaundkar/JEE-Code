package com.rm.dataprocessor;

import com.rm.dao.IDao;
import com.rm.dao.SubscriptionORMDao;
/**
 * This class is used for ORM type Data processing. This is template for managing data in ORM style.
 * @author Sagar
 * 
 */
public class ORMDataProcessor extends AbstractDataProcessor {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public IDao getSubscriptionDao() {
		// TODO Auto-generated method stub
		return new SubscriptionORMDao();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public IDao getUserDao() {
		// TODO Auto-generated method stub
		return null;
	}

}
