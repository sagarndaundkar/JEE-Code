package com.rm.dataprocessor;

import com.rm.dao.IDao;
/**
 * This abstract class handles responsibility of data processing
 * @author Sagar
 *
 */
public abstract class AbstractDataProcessor {

	private static final String defaultImpl = "com.rm.dataprocessor.SimpleDataProcessor";
	private static final String actualImpl  = "";//"com.rm.dataprocessor.ORMDataProcessor";
	
	static AbstractDataProcessor dataProcessor = instance(); 
	
	public static AbstractDataProcessor getInstance(){
		return dataProcessor;
	}

	private static AbstractDataProcessor instance() {
		// TODO Auto-generated method stub
		return DataProcessorHelper.getInstance(defaultImpl, actualImpl);
	}
	
	/**
	 * This method is used to get SubscriptionDao implementation
	 * @return Dao implementation
	 */
	abstract public IDao getSubscriptionDao();
	
	/**
	 * This method is used to get UserDao implementation.
	 * @return Dao implementation
	 */
	abstract public IDao getUserDao();
}
