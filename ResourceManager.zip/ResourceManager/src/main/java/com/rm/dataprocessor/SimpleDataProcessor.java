package com.rm.dataprocessor;

import com.rm.dao.IDao;
import com.rm.dao.SubscriptionJDBCDao;
import com.rm.dao.UserJDBCDao;
/**
 * This class is used for simple JDBC data processing
 * @author Sagar
 *
 */
public class SimpleDataProcessor extends AbstractDataProcessor {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public IDao getSubscriptionDao() {
		// TODO Auto-generated method stub
		return new SubscriptionJDBCDao();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public IDao getUserDao() {
		// TODO Auto-generated method stub
		return new UserJDBCDao();
	}

}
