package com.rm.webserviceexecutor;

import java.net.URI;
import java.net.URISyntaxException;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

public class JAXRSWebServiceExecutor {
	
	private static JAXRSWebServiceExecutor webServiceExecutor;
	public static final String METHOD_GET = "get";
	public static final String ACCEPT_HEADER_APPLICATION_JSON = "application/json";
	public static final String ACCEPT = "Accept";

	private JAXRSWebServiceExecutor(){
		
	}
	
	public static JAXRSWebServiceExecutor getInstance(){
		if(null == webServiceExecutor){
			webServiceExecutor = new JAXRSWebServiceExecutor();
		}
		return webServiceExecutor;
	}
	
	public Response callWebService(String URL, String methodType, String acceptHeader){
		WebTarget webTarget = null;
		Response response = null;
		Client client = ClientBuilder.newClient();
		URI uri;
		try {
			uri = new URI(URL);
			webTarget = client.target(uri);
			response = webTarget.request().header(ACCEPT, acceptHeader).get();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return response;
	}
	
}
