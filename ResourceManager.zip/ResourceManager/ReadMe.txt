Hi,

I integrated my application with AppDirect and tested successfully. Below are some observations which should be considered while evaluating code. 

1. id from eventURL is used as SUBSCRIPT_ID and USER_EVENT_ID in TSubscription and TUser table. These ids are mapped with newly generated RECORD_ID and USER_ID from respective table.
2. RECORD_ID and USER_ID in TSubscription and TUser table are accountIdentifier(integer) which is sent back to AppDirect and it can be used by AppDirect to perform various integration calls.
3. RECORD_ID and USER_ID in TSubscription and TUser table are integer and hence code has some casting logic. 
4. Current code implementation stores JSON data in database tables. Dao implementation have common interface IDao. This interface has been designed in such a way that it can be used with plain JDBC framework as well as ORM framework too. This will be dependent on dataprocessor implementation. 
5. Currently SimpleDataProcessor is used which is based on JDBC. ORMDataProcessor template has been created in order to show how ORM can be used with it. ORMDataProcessor and respective Dao its having, does not contains any implementation code. 
6. DataMapper classes are provided which can be useful to convert JsonString into associated POJO object. Such pojo object can be stored into DB in ORM manner.
7. Utility classes are provided for response generation, object-byte conversion and vise-versa. 
7. I could not differentiate between Subscription change and notification status. Hence implemented only one method i.e. update in RMAppResource. 
8. DB scripts are included in ResourceManagerScript.txt. 

Please let me know if you need any additional information from my side. 

Thanks,
Sagar




